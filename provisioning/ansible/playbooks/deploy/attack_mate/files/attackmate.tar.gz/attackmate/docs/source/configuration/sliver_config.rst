.. _sliver_config:

=============
sliver_config
=============

sliver_config stores all setttings to controll the connection to the sliver-API.

.. code-block:: yaml

   ###
   sliver_config:
     config_file: /home/attacker/.sliver-client/configs/attacker_localhost.cfg

.. confval:: config_file

   Path to the sliver-client configfile.

   :type: str
